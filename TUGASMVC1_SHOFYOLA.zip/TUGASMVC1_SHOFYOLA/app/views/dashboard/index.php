<h2>Dashboard</h2>

<div class="info"><b>HALLO, SELAMAT DATANG DI WEBSITE PLN SUKA MAJU.ADA YANG INGIN KAMU CARI??</b></div>

<header>
    <img src="img/PLN2.jpg" class="home" style="width: 400px; height: 350px;">
    <div class="info1"><b>MARI HIDUP DENGAN TERANGAN AGAR HIDUP SENANTIASA BERJALAN</div>
</header>